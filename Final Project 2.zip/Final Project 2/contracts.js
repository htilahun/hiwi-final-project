$(document).ready(function(){
    $(".whatis").click(function(){
        $("paragraph1").fadeIn();
    });
});